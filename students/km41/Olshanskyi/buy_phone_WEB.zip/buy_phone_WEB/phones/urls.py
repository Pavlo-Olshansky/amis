from django.conf.urls import url
from . import views

urlpatterns = [

    url(r'^details/(?P<pk>\d+)/$', views.ViewPhone.as_view(), name='view_phone_details'),

]
