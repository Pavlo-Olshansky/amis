from django.apps import AppConfig


class PhonesConfig(AppConfig):
    name = 'Phones'
