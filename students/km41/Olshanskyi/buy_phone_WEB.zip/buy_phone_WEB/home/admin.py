from django.contrib import admin
from .models import Profile
from django.contrib.auth.admin import UserAdmin as BaseUserAdmin


class UserAdmin(BaseUserAdmin):
    fieldsets = (
        (None, {'fields': ('email', 'password')}),
        ('User info', {'fields': ('username', 'first_name', 'last_name', 'email', 'user_photo', 'is_active', 'is_superuser', 'is_staff',)}),
    )    
    add_fieldsets = (
        (None, {
            'classes': ('wide',),
            'fields': ('username', 'first_name', 'last_name', 'email', 'password1', 'password2', 'user_photo', 'is_active', 'is_superuser', 'is_staff')}
        ),
    )

admin.site.register(Profile, UserAdmin)
