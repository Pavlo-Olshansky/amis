from django.conf.urls import url, include
from django.contrib import admin
from django.conf.urls.static import static
from django.conf import settings
from django.views.generic import TemplateView

urlpatterns = [

    url(r'^admin/', admin.site.urls),

	url(r'^', include('home.urls', namespace='home'), name='home'),

	url(r'^phone/', include('phones.urls', namespace='phones'), name='phones'),

	url(r'^order/', include('orders.urls', namespace='orders'), name='orders'),

	url(r'^database_error/', TemplateView.as_view(template_name="database_error.html")),

] + static(settings.STATIC_URL, document_root=settings.STATIC_ROOT) + static(settings.MEDIA_URL, document_root=settings.MEDIA_ROOT)
