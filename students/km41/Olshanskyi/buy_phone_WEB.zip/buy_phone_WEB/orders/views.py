from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required
from django.utils.decorators import method_decorator
from django.views import View
from .models import Order
from phones.models import Phone
from django.db import connection
from django.db import transaction

@method_decorator(login_required, name='dispatch')
class OrderView(View):
    template_name = 'orders/order-details.html'

    def get(self, request, pk):
        # user = request.user
        # order = Order.objects.get(pk=pk)
        # phone = order.phone
        # context = {'phone': phone,
        #            'user': user,
        #            'order': order}

        cursor = connection.cursor()
        cursor.execute('SELECT "PHONE_ID",\
        	"PHONE_PHOTO_URL", \
        	"PHONE_NAME", \
        	"PHONE_MODEL", \
        	"PHONE_DESCRIPTION", \
        	"PHONE_PRICE", \
        	"PHONE_QUANTITY", \
        	"USERNAME", \
        	"ORDER_CREATE_TIME", \
        	"ORDER_QUANTITY" \
        	FROM "OrderDetailsPage" \
        	WHERE "PHONE_ID" = {phone_id}'.format(phone_id=pk))

        PHONE_ID, PHONE_PHOTO_URL, PHONE_NAME, PHONE_MODEL, PHONE_DESCRIPTION, \
        PHONE_PRICE, PHONE_QUANTITY, USERNAME, ORDER_CREATE_TIME, \
        ORDER_QUANTITY = cursor.fetchone()
        
        context = {
        "PHONE_ID": PHONE_ID,
		"PHONE_PHOTO_URL": PHONE_PHOTO_URL,
		"PHONE_NAME": PHONE_NAME,
		"PHONE_MODEL": PHONE_MODEL,
		"PHONE_DESCRIPTION": PHONE_DESCRIPTION,
		"PHONE_PRICE": PHONE_PRICE,
		"PHONE_QUANTITY": PHONE_QUANTITY,
		"USERNAME": USERNAME,
		"ORDER_CREATE_TIME": ORDER_CREATE_TIME,
		"ORDER_QUANTITY": ORDER_QUANTITY
        }

        return render(request, self.template_name, context)
