from django.db import models
from django.conf import settings

class Order(models.Model):
    user = models.ForeignKey(
        settings.AUTH_USER_MODEL,
        verbose_name='User',
        on_delete=models.SET_NULL,
        null=True,
    )
    phone = models.ForeignKey(
        'phones.Phone',
        verbose_name='Phone',
        on_delete=models.SET_NULL,
        null=True,
    )
    quantity = models.PositiveIntegerField(
    	'quantity',
    	default=1,
    )
    create_time = models.DateTimeField(
        'Created',
        auto_now_add=True,
        null=True,
    )



    def __str__(self):
        return '{username} order of {phone} in {order_time}'.format(username=self.user.username,
            phone=self.phone.name, order_time=self.create_time)

    class Meta:
        verbose_name = "Order"
        verbose_name_plural = "Orders"
